import React, { useEffect, useState } from 'react';
import {
  Container,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Box,
  Alert,
} from '@mui/material';
import { format } from 'date-fns';

interface ServiceBooking {
  id: number;
  name: string;
  email: string;
  phone: string;
  bikeModel: string;
  serviceType: string;
  description: string;
  appointmentDate: Date;
  status: 'PENDING' | 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  createdAt: Date;
}

const ServiceHistory = () => {
  const [bookings, setBookings] = useState<ServiceBooking[]>([]);

  useEffect(() => {
    // Get bookings from localStorage
    const storedBookings = localStorage.getItem('serviceBookings');
    if (storedBookings) {
      const parsedBookings = JSON.parse(storedBookings).map((booking: any) => ({
        ...booking,
        appointmentDate: new Date(booking.appointmentDate),
        createdAt: new Date(booking.createdAt),
      }));
      setBookings(parsedBookings);
    }
  }, []);

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'completed':
        return 'success';
      case 'in_progress':
        return 'primary';
      case 'scheduled':
        return 'info';
      case 'pending':
        return 'warning';
      case 'cancelled':
        return 'error';
      default:
        return 'default';
    }
  };

  const formatDate = (date: Date) => {
    return format(date, 'MMM dd, yyyy hh:mm a');
  };

  if (bookings.length === 0) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Service History
        </Typography>
        <Alert severity="info" sx={{ mt: 2 }}>
          No service bookings found. Book a service to see your history here.
        </Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Service History
      </Typography>
      <TableContainer 
        component={Paper} 
        sx={{ 
          mt: 3,
          borderRadius: 2,
          boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.05)',
        }}
      >
        <Table>
          <TableHead>
            <TableRow sx={{ backgroundColor: 'primary.main' }}>
              <TableCell sx={{ color: 'white', fontWeight: 600 }}>Date</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 600 }}>Service Type</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 600 }}>Bike Model</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 600 }}>Description</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 600 }}>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {bookings.map((booking) => (
              <TableRow 
                key={booking.id}
                sx={{ 
                  '&:hover': { 
                    backgroundColor: 'rgba(0, 0, 0, 0.04)',
                  },
                }}
              >
                <TableCell>{formatDate(booking.appointmentDate)}</TableCell>
                <TableCell>{booking.serviceType}</TableCell>
                <TableCell>{booking.bikeModel}</TableCell>
                <TableCell>{booking.description}</TableCell>
                <TableCell>
                  <Chip
                    label={booking.status.replace('_', ' ')}
                    color={getStatusColor(booking.status) as any}
                    size="small"
                    sx={{ 
                      fontWeight: 500,
                      textTransform: 'capitalize',
                    }}
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Container>
  );
};

export default ServiceHistory; 