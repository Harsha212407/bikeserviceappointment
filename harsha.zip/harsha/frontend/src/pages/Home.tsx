import React from 'react';
import { Container, Typography, Grid, Card, CardContent, Button, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate = useNavigate();

  const services = [
    {
      title: 'Regular Maintenance',
      description: 'Complete bike checkup and maintenance service',
      price: 'Starting from $50',
    },
    {
      title: 'Repair Service',
      description: 'Professional repair for all bike issues',
      price: 'Starting from $30',
    },
    {
      title: 'Emergency Service',
      description: '24/7 emergency bike repair service',
      price: 'Starting from $80',
    },
  ];

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <Box textAlign="center" mb={6}>
        <Typography variant="h3" component="h1" gutterBottom>
          Welcome to Bike Service
        </Typography>
        <Typography variant="h5" color="textSecondary" paragraph>
          Professional bike maintenance and repair services
        </Typography>
        <Button
          variant="contained"
          color="primary"
          size="large"
          onClick={() => navigate('/book-service')}
          sx={{ mt: 2 }}
        >
          Book a Service
        </Button>
      </Box>

      <Grid container spacing={4}>
        {services.map((service, index) => (
          <Grid item xs={12} md={4} key={index}>
            <Card>
              <CardContent>
                <Typography variant="h5" component="h2" gutterBottom>
                  {service.title}
                </Typography>
                <Typography color="textSecondary" paragraph>
                  {service.description}
                </Typography>
                <Typography variant="h6" color="primary">
                  {service.price}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default Home; 