import React, { useState } from 'react';
import {
  Container,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Button,
  Box,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  SelectChangeEvent,
} from '@mui/material';

interface Appointment {
  id: number;
  customerName: string;
  date: string;
  serviceType: string;
  status: string;
  bikeModel: string;
  description: string;
}

// Mock data for appointments
const mockAppointments: Appointment[] = [
  {
    id: 1,
    customerName: 'John Doe',
    date: '2024-03-15',
    serviceType: 'Regular Maintenance',
    status: 'Pending',
    bikeModel: 'Trek FX 2',
    description: 'Regular maintenance and tune-up',
  },
  {
    id: 2,
    customerName: 'Jane Smith',
    date: '2024-03-16',
    serviceType: 'Brake Service',
    status: 'In Progress',
    bikeModel: 'Specialized Allez',
    description: 'Brake pad replacement',
  },
  {
    id: 3,
    customerName: 'Mike Johnson',
    date: '2024-03-17',
    serviceType: 'Tire Replacement',
    status: 'Scheduled',
    bikeModel: 'Giant Defy',
    description: 'Replace worn-out tires',
  },
];

const statusOptions = ['Pending', 'In Progress', 'Completed', 'Cancelled'];

const AdminDashboard = () => {
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [status, setStatus] = useState('');

  const handleStatusChange = (appointment: Appointment) => {
    setSelectedAppointment(appointment);
    setStatus(appointment.status);
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedAppointment(null);
    setStatus('');
  };

  const handleUpdateStatus = () => {
    // TODO: Implement API call to update status
    console.log('Updating status:', { appointmentId: selectedAppointment?.id, newStatus: status });
    handleCloseDialog();
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'completed':
        return 'success';
      case 'in progress':
        return 'primary';
      case 'pending':
        return 'warning';
      case 'cancelled':
        return 'error';
      default:
        return 'default';
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Admin Dashboard
      </Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Customer</TableCell>
              <TableCell>Date</TableCell>
              <TableCell>Service Type</TableCell>
              <TableCell>Bike Model</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {mockAppointments.map((appointment) => (
              <TableRow key={appointment.id}>
                <TableCell>{appointment.customerName}</TableCell>
                <TableCell>{appointment.date}</TableCell>
                <TableCell>{appointment.serviceType}</TableCell>
                <TableCell>{appointment.bikeModel}</TableCell>
                <TableCell>{appointment.description}</TableCell>
                <TableCell>
                  <Chip
                    label={appointment.status}
                    color={getStatusColor(appointment.status) as any}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <Button
                    variant="outlined"
                    size="small"
                    onClick={() => handleStatusChange(appointment)}
                  >
                    Update Status
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>Update Appointment Status</DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2 }}>
            <TextField
              select
              fullWidth
              label="Status"
              value={status}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setStatus(e.target.value)}
            >
              {statusOptions.map((option) => (
                <MenuItem key={option} value={option}>
                  {option}
                </MenuItem>
              ))}
            </TextField>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button onClick={handleUpdateStatus} variant="contained" color="primary">
            Update
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default AdminDashboard; 