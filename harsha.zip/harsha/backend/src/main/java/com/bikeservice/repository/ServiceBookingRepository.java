package com.bikeservice.repository;

import com.bikeservice.model.ServiceBooking;
import com.bikeservice.model.ServiceStatus;
import com.bikeservice.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDateTime;
import java.util.List;

public interface ServiceBookingRepository extends JpaRepository<ServiceBooking, Long> {
    List<ServiceBooking> findByUser(User user);
    List<ServiceBooking> findByStatus(ServiceStatus status);
    List<ServiceBooking> findByAppointmentDateBetween(LocalDateTime start, LocalDateTime end);
    List<ServiceBooking> findByUserAndStatus(User user, ServiceStatus status);
} 