package com.bikeservice.controller;

import com.bikeservice.model.ServiceBooking;
import com.bikeservice.model.ServiceStatus;
import com.bikeservice.service.ServiceBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "http://localhost:3000")
public class ServiceBookingController {

    @Autowired
    private ServiceBookingService serviceBookingService;

    @PostMapping
    public ResponseEntity<?> createBooking(@RequestBody ServiceBooking booking,
                                         Authentication authentication) {
        try {
            // TODO: Get user ID from authentication
            Long userId = 1L; // Temporary hardcoded user ID
            ServiceBooking createdBooking = serviceBookingService.createBooking(booking, userId);
            return ResponseEntity.ok(createdBooking);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/user")
    public ResponseEntity<?> getUserBookings(Authentication authentication) {
        try {
            // TODO: Get user ID from authentication
            Long userId = 1L; // Temporary hardcoded user ID
            List<ServiceBooking> bookings = serviceBookingService.getUserBookings(userId);
            return ResponseEntity.ok(bookings);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<?> getBookingsByStatus(@PathVariable ServiceStatus status) {
        try {
            List<ServiceBooking> bookings = serviceBookingService.getBookingsByStatus(status);
            return ResponseEntity.ok(bookings);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/date-range")
    public ResponseEntity<?> getBookingsByDateRange(@RequestParam LocalDateTime start,
                                                  @RequestParam LocalDateTime end) {
        try {
            List<ServiceBooking> bookings = serviceBookingService.getBookingsByDateRange(start, end);
            return ResponseEntity.ok(bookings);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateBookingStatus(@PathVariable Long id,
                                               @RequestParam ServiceStatus status) {
        try {
            ServiceBooking updatedBooking = serviceBookingService.updateStatus(id, status);
            return ResponseEntity.ok(updatedBooking);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateBooking(@PathVariable Long id,
                                         @RequestBody ServiceBooking booking) {
        try {
            booking.setId(id);
            ServiceBooking updatedBooking = serviceBookingService.updateBooking(booking);
            return ResponseEntity.ok(updatedBooking);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getBookingById(@PathVariable Long id) {
        try {
            ServiceBooking booking = serviceBookingService.getBookingById(id);
            return ResponseEntity.ok(booking);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
} 