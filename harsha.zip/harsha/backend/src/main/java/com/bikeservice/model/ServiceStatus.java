package com.bikeservice.model;

public enum ServiceStatus {
    PENDING,
    SCHEDULED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
} 