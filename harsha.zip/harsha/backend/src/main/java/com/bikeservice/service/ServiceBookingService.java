package com.bikeservice.service;

import com.bikeservice.model.ServiceBooking;
import com.bikeservice.model.ServiceStatus;
import com.bikeservice.model.User;
import com.bikeservice.repository.ServiceBookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ServiceBookingService {
    @Autowired
    private ServiceBookingRepository serviceBookingRepository;

    @Autowired
    private UserService userService;

    public ServiceBooking createBooking(ServiceBooking booking, Long userId) {
        User user = userService.findById(userId);
        booking.setUser(user);
        booking.setStatus(ServiceStatus.PENDING);
        return serviceBookingRepository.save(booking);
    }

    public ServiceBooking updateStatus(Long bookingId, ServiceStatus status) {
        ServiceBooking booking = serviceBookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
        booking.setStatus(status);
        return serviceBookingRepository.save(booking);
    }

    public List<ServiceBooking> getUserBookings(Long userId) {
        User user = userService.findById(userId);
        return serviceBookingRepository.findByUser(user);
    }

    public List<ServiceBooking> getBookingsByStatus(ServiceStatus status) {
        return serviceBookingRepository.findByStatus(status);
    }

    public List<ServiceBooking> getBookingsByDateRange(LocalDateTime start, LocalDateTime end) {
        return serviceBookingRepository.findByAppointmentDateBetween(start, end);
    }

    public ServiceBooking getBookingById(Long bookingId) {
        return serviceBookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
    }

    public ServiceBooking updateBooking(ServiceBooking booking) {
        ServiceBooking existingBooking = getBookingById(booking.getId());
        existingBooking.setServiceType(booking.getServiceType());
        existingBooking.setBikeModel(booking.getBikeModel());
        existingBooking.setDescription(booking.getDescription());
        existingBooking.setAppointmentDate(booking.getAppointmentDate());
        existingBooking.setNotes(booking.getNotes());
        return serviceBookingRepository.save(existingBooking);
    }
} 